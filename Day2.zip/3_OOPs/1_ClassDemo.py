# class Employee:
#     pass

# print(Employee)
# e = Employee()
# print(e)
# print(type(e))

# print(int)
# a = int(10)
# print(a)
# print(type(a))


class Employee:
    def __init__(self, id=0, name="NA", desig="NA", sal=0):
        self._id = id
        self._name = name
        self._designation = desig
        self._salary = sal

    def getId(self):
        return self._id

    def getName(self):
        return self._name

    def getDesignation(self):
        return self._designation

    def getSalary(self):
        return self._salary

    def setSalary(self, value):
        if(value < 10000):
            raise ValueError("I will not work less tha 10000")
        self._salary = value


# e = Employee()
e = Employee(1, "Manish", "Trainer", 12345)
print("Id: ", e.getId())
print("Name: ", e.getName())
print("Designation: ", e.getDesignation())
print("Salary: ", e.getSalary())

try:
    e.setSalary(0)
    print("Salary: ", e.getSalary())
except Exception as e:
    print(e)
    