# class Employee:
#     def __init__(self, id=0, name="NA", desig="NA", sal=0):
#         self._id = id
#         self._name = name
#         self._desig = desig
#         self._sal = sal

#     def getId(self):
#         return self._id

#     def getName(self):
#         return self._name

#     def getDesignation(self):
#         return self._desig

#     def getSalary(self):
#         return self._sal

#     def setSalary(self, sal):
#         if sal < 10000:
#             raise ValueError("I will not work less than this amount")
#         self._sal = sal


# class Manager(Employee):
#     def __init__(self, id=0, name="NA", desig="NA", sal=0, location="Pune"):
#         super().__init__(id, name, desig, sal)
#         self._location = location

#     def getLocation(self):
#         return self._location

#     def setSalary(self, sal):
#         if sal < 100000:
#             raise ValueError("I will not work less than 100000")
#         self._sal = sal


# e = Manager(1, "Manish", "Trainer", 12345)
# print("Id: ", e.getId())
# print("Name: ", e.getName())
# print("Designation: ", e.getDesignation())
# print("Salary: ", e.getSalary())
# print("Location: ", e.getLocation())

# try:
#     e.setSalary(0)
#     print("Salary: ", e.getSalary())
# except Exception as e:
#     print(e)


# -------------------------------------------------------------------- Multiple Inheritance
class A:
    def __init__(self):
        print("Class A init")

    def methodA(self):
        print("Class A")

    def methodS(self):
        print("Same Name Class A")


class B:
    def __init__(self):
        print("Class B init")

    def methodB(self):
        print("Class B")

    def methodS(self):
        print("Same Name Class B")


# class C(A, B):
#     def __init__(self):
#         super().__init__()
#         print("Class C init")

class C(B, A):
    def __init__(self):
        super().__init__()
        print("Class C init")


obj = C()
obj.methodA()
obj.methodB()
obj.methodS()
