# def hello():
#     pass


# def hello():
#     print('Hello World')


# hello()
# print(hello)
# print(type(hello))

def add(x, y):
    return x+y


# print(add(2, 3))
# print(add(2, 3, 5))             # TypeError: add() takes 2 positional arguments but 3 were given
# print(add(2))                   # TypeError: add() missing 1 required positional argument: 'y'


def addAll(numbers):
    print(type(numbers))
    print(numbers)


addAll([2, 3, 4, 5, 6])
addAll(2)
addAll(["2", "3"])
addAll({1: 23})
addAll("Manish")
# addAll(2, 3, 4)
