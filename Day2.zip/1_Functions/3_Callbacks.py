# If Function is considered as datatype, following will applicable

# Can we create a variable of type int, inside a function
# If yes, we can create a variable of type function, inside a function, also

# Can we return a variable of type int, from a function
# If yes, we can return a variable of type function, from a function, also

# Can we pass a variable of type int, to a function
# If yes, we can pass a variable of type function, to a function, also

# def average(*numbers):
#     sum = 0
#     for n in numbers:
#         sum += n
#     if len(numbers):
#         return sum / len(numbers)
#     else:
#         return sum


# result = average(1, 2, 3, 4, 5, 6, 7, 8, 9)
# print(result)

# ------------------------------------------ Fn passed as argument to another Fn

# Dev 1
# def average(callback, *numbers):
#     sum = 0
#     for n in numbers:
#         sum += n
#     if len(numbers):
#         callback(sum / len(numbers))
#     else:
#         callback(sum)


# # Dev 2
# def printResult(result):
#     print("Result is: ", result)


# average(printResult, 1, 2)
# average(printResult, 1, 2, 3, 4, 5)
# average(printResult, 1, 2, 3, 4, 5, 6, 7, 8, 9)


# average(lambda result: print("Result is: ", result), 1, 2)

# ------------------------------------------------------

# numArr = [1, 2, 3, 4, 5]

# resultArr = []
# for item in numArr:
#     n = item*10
#     resultArr.append(n)


# def processItem(item):
#     return item*10


# resultArr = []
# for item in numArr:
#     resultArr.append(processItem(item))

# print(resultArr)

# resultArr1 = map(processItem, numArr)
# print(list(resultArr1))

# resultArr2 = map(lambda item: item*10, numArr)
# print(list(resultArr2))

# resultArr3 = map(lambda item: item*5, numArr)
# print(list(resultArr3))

# resultArr4 = map(lambda item: item*2, numArr)
# print(list(resultArr4))

# --------------------------------------------------------------
# numArr = [1, 2, 3, 4, 5, 6, 7, 8, 9]

# # r = []
# # for item in numArr:
# #     if item % 2 == 0:
# #         r.append(item)

# r = list(filter(lambda item: item % 2 == 0, numArr))

# print(r)

# -------------------------------------------------------------
import operator
import functools

numArr = [1, 2, 3, 4, 5, 6, 7, 8, 9]

# sum = functools.reduce(lambda a, b: a+b, numArr)
# print("Result: ", sum)

# r = functools.reduce(lambda a, b: a if a > b else b, numArr)
# print("Max: ", r)

# sum = functools.reduce(operator.add, numArr)
# print("Result: ", sum)

# r = functools.reduce(operator.mul, numArr)
# print("Multiply Result: ", r)

# r = functools.reduce(max, numArr)
# print("Max: ", r)

# ----------------------------------------------------- Query
sum = 0
for i in numArr:
    sum += i

print("Result: ", sum)

def addAll(numbers):
    sum = 0
    for i in numbers:
        sum += i
    return sum

sum = addAll(numArr)
print("Result: ", sum)

sum = functools.reduce(lambda a, b: a+b, numArr)
print("Result: ", sum)

sum = functools.reduce(operator.add, numArr)
print("Result: ", sum)