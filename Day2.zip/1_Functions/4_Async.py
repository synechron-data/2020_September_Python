import random
import threading


def set_interval(fn, sec):
    def fn_wrapper():
        set_interval(fn, sec)
        fn()
    t = threading.Timer(sec, fn_wrapper)
    t.start()
    return t


def get_string():
    nameList = ["Python", "JavaScript", "Java", "DotNet", "Scala"]
    return random.choice(nameList)

# for r in range(6):
    # s = get_string()
    # print(s)

# def caller():
#     s = get_string()
#     print(s)

# set_interval(caller, 2)


def push_string(cb):
    def push():
        s = random.choice(nameList)
        cb(s)

    nameList = ["Python", "JavaScript", "Java", "DotNet", "Scala"]
    set_interval(push, 2)


def display(s):
    print(s)


push_string(display)
print("---------------------- Last Line ------------------")
