# def sqrt(x):
#     guess = x
#     i = 0
#     while guess * guess != x and i < 20:
#         guess = (guess + x/guess)/2.0
#         i += 1
#     return guess

# print(sqrt(9))
# print(sqrt(2))
# print(sqrt(-1))

# -----------------------------------------------------------------


# def sqrt(x):
#     if(x < 0):
#         raise ValueError("Error: Cannot use negative number {}".format(x))
#     guess = x
#     i = 0
#     while guess * guess != x and i < 20:
#         guess = (guess + x/guess)/2.0
#         i += 1
#     return guess

# def sqrt(x):
#     guess = x
#     i = 0
#     try:
#         while guess * guess != x and i < 20:
#             guess = (guess + x/guess)/2.0
#             i += 1
#     except ZeroDivisionError:
#         # Log the actual Exception
#         raise ValueError("Error: Cannot use negative number {}".format(x))
#     return guess

def sqrt(x):
    if(x < 0):
        raise ValueError("Error: Cannot use negative number {}".format(x))
    guess = x
    i = 0
    try:
        while guess * guess != x and i < 20:
            guess = (guess + x/guess)/2.0
            i += 1
    except Exception:
        # Log the actual Exception
        raise Exception("Error: Executing Logic")
    finally:
        print("Hello from Finally")
    return guess


def catchException(func):
    def exceptionHandler(*args, **kwargs):
        try:
            return func(*args, *kwargs)
        except Exception as e:
            print(e)

    return exceptionHandler


@catchException
def call():
    print(sqrt(9))
    print(sqrt(2))
    print(sqrt(-1))


call()

# def call():
#     print(sqrt(9))
#     print(sqrt(2))
#     print(sqrt(-1))


# try:
#     call()
# except Exception as e:
#     print(e)
