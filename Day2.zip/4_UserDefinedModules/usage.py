# import words
# words.fetch_words()

# from words import fetch_words
# fetch_words()

# import check.words
# import words

# check.words.fetch_words()
# words.fetch_words()

# from words import fetch_words
# from check.words import fetch_words
# fetch_words()

from words import fetch_words as fw1
from check.words import fetch_words as fw2

fw1()
fw2()