# # a
# # print(a)

# # a = None
# # print(a)
# # print(type(a))

# # # a = 10
# # # print(a)
# # # print(type(a))

# # # a = "Synechron"
# # # print(a)
# # # print(type(a))

# # a = 10.5
# # a = "Synechron"
# # print(a)
# # print(type(a))

# # a, b, c = 10, 20.5, "ABC"
# # a, b, c = 10, 20.5      # ValueError: not enough values to unpack
# # a = b = c = 10

# # print(a)
# # print(type(a))

# # print(b)
# # print(type(b))

# # print(c)
# # print(type(c))

# # a = {}
# # print(a)
# # print(type(a))

# # a = []
# # print(a)
# # print(type(a))

# # ---------------------------------------------------------

# # a = "Synechron"
# # print(a)
# # print(type(a))

# # del a       # NameError: name 'a' is not defined
# # print(a)
# # print(type(a))

# # ------------------------------------------------------

# # x = "Synechron"
# # y = "Synechron"

# # print(x)
# # print(y)

# # print(type(x))
# # print(type(y))

# # print(id(x))
# # print(id(y))
# # # print(x is y)

# # x = "Manish"

# # print(x)
# # print(y)

# # print(id(x))
# # print(id(y))

# x = 10
# print(x)
# print(type(x))
# print(id(x))

# y = x
# print(y)
# print(type(y))
# print(id(y))

# x = 20
# print(x)
# print(type(x))
# print(id(x))
