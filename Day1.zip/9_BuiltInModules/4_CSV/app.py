import csv
import collections

# myData = [
#     ["fname", "lname", "city"],
#     ["Manish", "Sharma", "Pune"],
#     ["Abhijeet", "Gole", "Pune"]
# ]

# myFile = open('test.csv', 'w', newline='')

# with myFile:
#     writer = csv.writer(myFile)
#     writer.writerows(myData)

# print("CSV file created....")

# ------------------------------------------------ Read

# with open('test.csv') as file:
#     reader = csv.reader(file, delimiter=",")

#     for row in reader:
#         print(row)

# with open('test.csv') as file:
#     reader = csv.DictReader(file)

#     for row in reader:
#         print(row)

results = []
with open('test.csv') as file:
    reader = csv.DictReader(file)

    for row in reader:
        results.append(row)

grouped = collections.defaultdict(list)
# print(grouped)

for item in results:
    grouped[item['city']].append(item)

# print(grouped)

for k, v in grouped.items():
    print()
    print(k)
    print(str(v))