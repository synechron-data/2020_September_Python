import sys

# print("Hello {}, Welcome to {}".format("Abhijeet", "Python"))

# print("Hello {}, Welcome to {}".format(sys.argv[1], sys.argv[2]))
# py app.py Manish Python_World

# print(sys.maxsize)
print(sys.path)
print(sys.version)