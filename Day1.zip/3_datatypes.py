# int       Signed & Unlimited precision

# print(10)       # decimal
# print(0b10)       # binary
# print(0o10)       # octal
# print(0x10)       # hex
# print(type(0x10))

# print(int(3.5))
# print(int(-3.5))
# print(int(456))
# print(int("1010"))
# print(int("1010", 2))
# print(int("11", 2))

# print(int(True)+10)

# float     Double Precision (64 bit)
# print(3.125)
# print(type(3.125))
# print(3000000000000000000000000000000000000000000000000000000000000000000.125)
# print(3e8)
# print(float(7))

a = True
# print(type(a))

print(bool(1))
print(bool(0))
print(bool(-1))
print(bool(""))
print(bool(None))
print(bool("abc"))