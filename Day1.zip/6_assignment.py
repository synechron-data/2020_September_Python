data = [2, 4, 3, 1, 1, 4]

# r = set(data)
# print(r)

# ------------------------------------
# Result - {2: 1, 4: 2, 3: 1, 1: 2}
# r = {}

# for i in data:
#     if i in r:
#         r[i] = r[i]+1
#     else:
#         r[i] = 1

# print(r)

# # ----------------------------------
# r = {}

# for i in data:
#     r[i] = data.count(i)

# print(r)

# # ---------------------------------- Comprehensions
# r = dict((i, data.count(i)) for i in data)
# print(r)

# data = data + [2, 4, 3, 1, 1, 4]
# print(data)

# r = dict((i, data.count(i)) for i in data)
# print(r)

# ---------------------------------- Counter from collections
from collections import Counter
r = dict(Counter(data))
print(r)