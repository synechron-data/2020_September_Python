# from itertools import permutations
# result = permutations('ABCD', 2)

# for r in result:
#     print(r)

# # ---------------------------------------------------
# from itertools import groupby
# colors = ['blue', 'red', 'blue', 'yellow', 'blue', 'red']

# # r = [(i, len(list(c))) for i, c in groupby(colors)]
# # r = [(i, len(list(c))) for i, c in groupby(sorted(colors))]
# r = [(i, len(list(c))) for i, c in groupby(sorted(colors, reverse=True))]

# print(r)

# ---------------------------------------------------
# from itertools import accumulate
# arr = [1, 2, 3, 4, 5]

# result = accumulate(arr)

# from itertools import accumulate
# from operator import mul

# arr = [1, 2, 3, 4, 5]

# result = accumulate(arr, mul)

# for r in result:
#     print(r)

from itertools import accumulate, combinations

data = [5, 2, 6, 4, 5, 9, 1]
# result = accumulate(data, max)
result = combinations(data, 2)

print(list(result))