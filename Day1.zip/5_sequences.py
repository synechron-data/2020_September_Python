# ---------------------------------------- List
# # data = list()

# data = [1, 2, 3, 4, 5, "Pune"]
# print(data)
# print(type(data))

# print(data[0])
# print(data[1:4])

# print(id(data))
# data.append(6)
# # data[0] = "Test"
# # data = [1,2]
# print(data)
# print(id(data))

# # ---------------------------------------- Tuple
# # data = tuple()

# data = (1, 2, 3, 4, 5, "Pune")
# print(data)
# print(type(data))

# # print(data[0])
# # print(data[1:4])

# # print(id(data))
# # data = (1,2)
# # print(data)
# # print(id(data))

# for a in data:
#     print(a)
#     print("Inside Loop")

# print("Outside Loop")

# # ---------------------------------------- Set
# # data = set()

# data = {1, 2, 3, 4, 5, "Pune", 1, 2, 3, 4, 5, "Pune"}
# # data = [1, 2, 3, 4, 5, "Pune", 1, 2, 3, 4, 5, "Pune"]
# print(data)
# print(type(data))

# for a in data:
#     print(a)

# ---------------------------------------- Dict
# data = dict()

# data = {
#     "Manish": 123456,
#     "Abhijeet": 123456,
#     "Ramakant": "123456",
#     "Pravin": True
# }
# print(data)
# print(type(data))

# for a in data:
#     print(a)

# -------------------------------------------- Range
# nRange = range(0, 10)
# print(nRange)
# print(type(nRange))

# for a in nRange:
#     print(a)

# data = list(range(5, 10))
# data = tuple(range(5, 10))
# data = tuple(range(6))

# print(data)
# print(type(data))

# ----------------------------------------------- Input and create a dynamic list
numberList = []

n = int(input("Enter number of items: "))

for i in range(n):
    inp = int(input())
    numberList.append(inp)

# for i in numberList:
#     print(i, end=" ")

print(numberList)
print(numberList + [45, 67])
print(numberList * 3)

print(10 in numberList)
print(10 not in numberList)

print(numberList[1])
print(numberList[1:3])
