# name1 = "Synechron"
# name2 = 'Pune Phase 3'
# name3 = 'A'
# name4 = """Hi There
#     Hello
#     How Are you
#                 Test"""

# name5 = '''Hi There
#     Hello
#     How Are you
#                 Test'''

# print(name1)
# print(type(name1))

# print(name2)
# print(type(name2))

# print(name3)
# print(type(name3))

# print(name4)
# print(type(name4))

# print(name5)
# print(type(name5))

a = '"Hello"'
print(a)
# print(type(a))

print(a[0])
print(a[1])
print(a[1:4])

print(type(a[1]))
