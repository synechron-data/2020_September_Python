words = """Lorem ipsum dolor sit amet consectetur adipisicing elit.
Reiciendis eum, laudantium harum voluptas, debitis aliquid porro accusantium ducimus corporis
sit aspernatur tenetur magnam vitae nesciunt officiis aperiam cupiditate similique explicabo.""".split()

# print(words)
# print(type(words))

# Write a logic to, create a List of numbers representing length of each word in words list

# wlength = []
# for word in words:
#     wlength.append(len(word))

# print(wlength)

# wlength = list(map(lambda word: len(word),words))
# print(wlength)

# ----------------------------------------------------- Comprehension

# List Comprehension - [exp(item) for item in iterable if exp]
# Dict Comprehension - {exp(item) for item in iterable if exp}

# wlength = [len(word) for word in words]
# print(wlength)

from math import factorial
from pprint import pprint as pp

# factorials = [factorial(n) for n in range(20)]
# print(factorials)

# factorials_len = [len(str(factorial(n))) for n in range(20)]
# print(factorials_len)

# inpList = list(range(20))

# n = "abc"
# print("Before, ", n)

# # evList = []
# # for n in inpList:
# #     if n%2==0:
# #         evList.append(n)

# evList = [n for n in inpList if n%2==0]

# print(evList)
# print("After, ", n)

# ---------------------------------- Square of each number from range 0, 10

# result = [x*x for x in range(10)]
# result = {x*x for x in range(10)}
# result = {x: x*x for x in range(10)}

# print(result)
# print(type(result))

# ------------------------------------------------------

# countrycapital = {'India': 'Delhi', 'Morocco': 'Rabat',
#                   'Netherlands': 'Amsterdam', 'UAE': 'Abu Dhabi'}

# pp(countrycapital)


# capitalcountry = {capital:country for country,capital in countrycapital.items()}
# pp(capitalcountry)

# capitals = [capital for country,capital in countrycapital.items()]
# pp(capitals)

# -----------------------------------------------------------

data = [[1, 2, 3], [4, 5, 6], [7, 8, 9]]
pp(data)

# flatData = []
# for item in data:
#     for value in item:
#         flatData.append(value)

# flatData = [value for item in data for value in item]
# pp(flatData)

# Generator Comprehension
flatData = (value for item in data for value in item)
pp(flatData)
pp(list(flatData))

# for v in flatData:
#     print(v)